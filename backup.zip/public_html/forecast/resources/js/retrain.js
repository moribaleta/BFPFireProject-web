var map_report = {
    time: [],
    day: [],
    month: [],
    cause: [],
    alarm: [],
    temp: [],
    type: [],
    district: []
}

function getData(key, data) {
    if (map_report[key].includes(data)) {
        return map_report[key].indexOf(data)
    } else {
        map_report[key].push(data)
        return (map_report[key].length - 1)
    }
}

var max = 0
var counter = 0

function processdata(reports_readable) {
    max = reports_readable.length - 1
    reports_readable.forEach(element => {
        let new_element = element
        //new_element.date        = getData("date",element.date)
        let date = element.date.split("-")
        var time = date[0].split("_")[0]
        var day = date[0].split("_")[1]
        var month = date[1]
        time = getData("time", time)
        month = getData("month", month)
        new_element.date = time + "_" + day + "_" + month
        new_element.cause = getData("cause", element.cause)
        new_element.alarm = getData("alarm", element.alarm_level)
        new_element.temp = element.temperature
        new_element.establishment_type = getData("type", element.establishment_type)
        new_element.district = getData("district", element.district)
        saveReport(new_element,onFire)
    });
}

function onFire(){
    if (max == counter) {
        getReports(false,generateClassifierFromDataSet)
        counter = 0
    }else{
        counter ++;
    }
}

function retrain_classifier() {
    deleteReports()
    getReports(true, processdata)
    //getReports(false,generateClassifierFromDataSet)
}

function retrain_classifier_withdataset(data){
    processdata(data)
}