//let host = "http://localhost/phdfire/"
//let host = "https://bfpfireproject.000webhostapp.com/phdfire/phdfire/"
let host = "https://bfpforecast.000webhostapp.com/phdfire/"

var forecast_data = null

function getReports(isReadable, func_callback) {
    $.get(host + "getreports.php", {
        readable: isReadable
    }, function (data, status) {
        if (status == "success") {
            func_callback(JSON.parse(data))
        }
    });
}

function saveReportReadable(item) {
    $.post(host + "savereports.php", {
            readable: true,
            date: item.date,
            cause: item.cause,
            alarm: item.alarm,
            temperature: item.temp,
            establishment_type: item.type,
            district: item.district
        },
        function (data, status) {
            console.log("Data: " + data + "\nStatus: " + status);
        });
}

function saveReport(item, callback) {
    $.post(host + "savereports.php", {
            readable: false,
            date: item.date,
            cause: item.cause,
            alarm: item.alarm,
            temperature: item.temp,
            establishment_type: item.establishment_type,
            district: item.district
        },
        function (data, status) {
            console.log("Data: " + data + "\nStatus: " + status);
            callback()
        });
}

function deleteReports() {
    $.post(host + "deletereports.php", {

    }, function (data, status) {
        console.log(data + status)
    })
}
//getReports()

function getClassifier() {
    $.get(host + "getclassifier.php", function (data, status) {
        //alert("Data: " + data + "\nStatus: " + status);
        //alert(status)
        console.log("getClassifier: %o",data)
        classifierGenerate(data)
    });
}

function saveClassifier(model, callback) {
    $.get(host + "saveclassifier.php?model=" + model, function (data, status) {
        console.log(data)
        //alert("Data: " + data + "\nStatus: " + status);
        //alert(status)
        //console.log(data)
        if (callback != null) {
            callback()
        } else {
            classifierSaved()
        }
    });
}

//files
function getFiles(type, response) {
    $.get(host + "getFiles.php?type=" + type, {

    }, function (data, status) {
        console.log(data)
        response(JSON.parse(data))
    })
}

function deleteFile(id, filename, response) {
    $.get(host + "deletefile.php", {
        file: filename,
        id: id
    }, function (data, status) {
        console.log(data)
        response(response)
    })
}